import * as React from "react";
import { Stack, IStackTokens, DefaultButton, PrimaryButton, IStackItemStyles, DefaultPalette, IStackStyles, TextField, IStackProps, BaseButton, Button, TextFieldBase, ITextField } from "@fluentui/react"
import { Accordion, AccordionHeader, AccordionItem, AccordionPanel } from "@fluentui/react-components";

const stackTokens: IStackTokens = { childrenGap: 40 };

const stackStyles: IStackStyles = {
  root: {
    // background:"red",
  },
};

const stackItemStyles: IStackItemStyles = {
  root: {
    // background: DefaultPalette.themePrimary,
    color: DefaultPalette.white,
    padding: 5,
  },
};

const itemAlignmentsStackStyles: IStackStyles = {
  root: {
    background: DefaultPalette.themeTertiary,
    height: 100,
  },
};
const itemAlignmentsStackTokens: IStackTokens = {
  childrenGap: 5,
  padding: 5,
};

const columnProps: Partial<IStackProps> = {
  tokens: { childrenGap: 15 },
  styles: { root: { width: 300 } },
};

//const SummarizeButton:React.FunctionComponent=()=>{
function AISummarizeControl() {
  const containerRef = React.useRef<HTMLDivElement | null>(null);
  const textFieldRef = React.useRef<ITextField | null>(null);
  const [summary,setSummary]=React.useState<string>("");
  const [isReqInprogress,setisReqInprogress]=React.useState<boolean>(false);
  const [summaryPlaceHolder,setSummaryPlaceHolder]=React.useState<string>("AI Summarizes your call notes.");

  const Summarize_Btn_Click = async () => {
    setSummaryPlaceHolder("AI is generating a summary of your call notes…")
     setisReqInprogress(true)
     setSummary("")
    const endpoint = `https://dynamics-ai-functions.azurewebsites.net/api/Dynmics-AI-Function?code=82_aA8j3R8_lQoZC0SY7xLq5MLXioBxrW89SHjRffZejAzFuKO73UQ==&summarize=true`;//this._context?.parameters?.endpoint?.raw ?? this._context?.parameters?.apiEndpoint?.raw ?? "https://YOUR-AZURE-ENDPOINT.openai.azure.com";
    const call_notes_text = textFieldRef.current?.value;

    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: call_notes_text //JSON.stringify({ message: text })
    });

    const result = await response.text();
    setSummary(result);
    setisReqInprogress(false)
  }


  return (
    <Accordion
      // multiple
      // collapsible
      
    >
      <AccordionItem value="details">
        <AccordionHeader>
          <PrimaryButton onClick={Summarize_Btn_Click}>AI Summarize</PrimaryButton>
        </AccordionHeader>
        <AccordionPanel>
          <Stack enableScopedSelectors styles={stackStyles} >
            <Stack.Item order={2} styles={stackItemStyles}>
              <div ref={containerRef} style={{ maxHeight: '300px', overflowY: 'scroll' }}>
                <TextField placeholder="Please enter call notes." multiline autoAdjustHeight scrollContainerRef={containerRef}
                 disabled={isReqInprogress}
                 componentRef={textFieldRef} />
              </div>
            </Stack.Item>
            <Stack.Item order={3} styles={stackItemStyles}>
              <div ref={containerRef} style={{ maxHeight: '300px', overflowY: 'scroll' }}>
                <TextField value={summary} placeholder={summaryPlaceHolder} multiline autoAdjustHeight
                 scrollContainerRef={containerRef} readOnly content={summary}

                 />
              </div>
            </Stack.Item>
           
          </Stack>

        </AccordionPanel>
      </AccordionItem>
    </Accordion>

  );
}

export default AISummarizeControl